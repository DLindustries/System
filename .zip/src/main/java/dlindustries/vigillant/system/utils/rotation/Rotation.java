package dlindustries.vigillant.system.utils.rotation;


public record Rotation(double yaw, double pitch) {
}
