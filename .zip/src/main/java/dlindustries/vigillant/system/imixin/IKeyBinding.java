package dlindustries.vigillant.system.imixin;

public interface IKeyBinding {
	boolean isActuallyPressed();

	void resetPressed();
}
