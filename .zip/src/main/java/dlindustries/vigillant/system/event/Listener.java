package dlindustries.vigillant.system.event;

import java.util.EventListener;

public interface Listener extends EventListener {
}
