package dlindustries.vigillant.system.module.setting;

public class StringSetting extends Setting<StringSetting> {
    private String value;
//Anticrash fix cuz argon settings cheeks
    public StringSetting(CharSequence name, String defaultValue) {
        super(name);
       //no nule
        this.value = (defaultValue != null) ? defaultValue : "";
    }

    public void setValue(String value) {
        //no null
        this.value = (value != null) ? value : "";
    }

    public String getValue() {
        // Defensive in case something bypasses constructor/setValue
        if (this.value == null) {
            this.value = "";
        }
        return this.value;
    }
}
