package dlindustries.vigillant.system.module.modules.donut;

import dlindustries.vigillant.system.event.events.TickListener;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.utils.EncryptedString;

public final class ShulkerDropper extends Module implements TickListener {
    private final NumberSetting delay =
            new NumberSetting(EncryptedString.of("Delay"), 0.0, 20.0, 1.0, 1.0);
    private int delayCounter = 0;

    public ShulkerDropper() {
        super(EncryptedString.of("Shulker Dropper"),
                EncryptedString.of("Goes to shop buys shulkers and drops automatically"),
                -1, Category.Donut);
        this.addSettings(this.delay);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        system.INSTANCE.getEventManager().add(TickListener.class, this);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        system.INSTANCE.getEventManager().remove(TickListener.class, this);
    }

    @Override
    public void onTick() {
        if (this.mc.player == null) return;
        if (this.delayCounter > 0) {
            --this.delayCounter;
            return;
        }
        final ScreenHandler currentScreenHandler = this.mc.player.currentScreenHandler;
        if (!(currentScreenHandler instanceof GenericContainerScreenHandler)) {
            this.mc.getNetworkHandler().sendChatCommand("shop");
            this.delayCounter = 20;
            return;
        }
        if (((GenericContainerScreenHandler) currentScreenHandler).getRows() != 3) return;

        if (currentScreenHandler.getSlot(11).getStack().isOf(Items.END_STONE)
                && currentScreenHandler.getSlot(11).getStack().getCount() == 1) {
            this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 11, 0,
                    SlotActionType.PICKUP, this.mc.player);
            this.delayCounter = 20;
            return;
        }
        if (currentScreenHandler.getSlot(17).getStack().isOf(Items.SHULKER_BOX)) {
            this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 17, 0,
                    SlotActionType.PICKUP, this.mc.player);
            this.delayCounter = 20;
            return;
        }
        if (currentScreenHandler.getSlot(13).getStack().isOf(Items.SHULKER_BOX)) {
            this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 23, 0,
                    SlotActionType.PICKUP, this.mc.player);
            this.delayCounter = this.delay.getValueInt();
            this.mc.player.networkHandler.sendPacket(
                    new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.DROP_ALL_ITEMS,
                            BlockPos.ORIGIN, Direction.DOWN));
        }
    }
}
